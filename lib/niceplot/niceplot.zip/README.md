Read and run nicedemo.
